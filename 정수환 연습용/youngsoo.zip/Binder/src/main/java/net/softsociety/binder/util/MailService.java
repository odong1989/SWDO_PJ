package net.softsociety.binder.util;

public interface MailService {
	 
    public void sendEmail(Mail mail);
}
