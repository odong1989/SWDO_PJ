package net.softsociety.binder.vo;

import lombok.Data;

@Data
public class GroupJoin {

	private int group_no;
	private String member_id;
	private int member_level;
	private String group_joindate;
}
