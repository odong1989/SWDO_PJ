package com.project.dajare.dao;

import java.util.ArrayList;

import com.project.dajare.vo.GroupJoin;

public interface GroupJoinMapper {
	public GroupJoin selectGroupJoinMember(GroupJoin vo);
	public String selectGroupJoinMemberOne(String memberCheck);
}
