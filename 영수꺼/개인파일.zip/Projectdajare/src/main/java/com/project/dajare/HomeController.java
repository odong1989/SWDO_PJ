package com.project.dajare;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.dajare.dao.GroupJoinDAO;
import com.project.dajare.vo.GroupJoin;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private GroupJoinDAO dao;
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	@RequestMapping(value="/signup", method=RequestMethod.GET)
	public String signup() {
		return "signup";
	}
	
	@RequestMapping(value="/mainboard", method=RequestMethod.GET)
	public String mainboard() {
		return "mainboard";
	}
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */

	@RequestMapping(value="/vuepractice", method=RequestMethod.GET)
	public String vuelist(GroupJoin vo, HttpSession session, Model model) {
		int groupno = 1;
		vo.setGroup_no(groupno);
		logger.info("그룹화면{}",vo);
		GroupJoin join = dao.selectGroupJoinMember(vo);
		logger.info("그룹화면{}",join);
		model.addAttribute("gjoin",join);
		return "vuepractice";
	}
	
	@RequestMapping(value="selectGJM", method=RequestMethod.GET)
	@ResponseBody
	public String vuelist2(GroupJoin vo, String memberCheck) {
		logger.info("그룹화면{}",vo);
		String memberCheck2 = dao.selectGroupJoinMemberOne(memberCheck);
		String chk = null;
		if (memberCheck2 != null) {
			chk = "true";
		} else {
			chk = "false";
		}
		return chk;
	}
	
	@RequestMapping(value="/modaltest", method=RequestMethod.GET)
	public String modal() {
		return "modaltest";
	}
	@RequestMapping(value="/vueModal", method=RequestMethod.GET)
	public String vueModal() {
		return "vueModal";
	}
	
	
}
